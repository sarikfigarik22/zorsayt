import React from 'react'
import { Link } from 'react-router-dom'
import './App.css'
import DividerCustom from './components/DividerCustom'

const App = () => {
  return (
    <div>

      <DividerCustom text={"Dilshod urod"} />

      <div className='max-w-[80%] mx-auto container flex flex-wrap gap-x-10 gap-y-10'>
        <Link to={'/currency'} className='flex-1 p-20 rounded-lg glass flex items-center justify-center min-w-[40%] text-3xl shadow-lg group hover:text-red-500 hover:shadow-red-500 transition-all active:scale-90'>
          Currency Converter
        </Link>

        <Link to={'/mirodil'} className='flex-1 p-20 rounded-lg glass flex items-center justify-center min-w-[40%] text-3xl shadow-lg group hover:text-red-500 hover:shadow-red-500 transition-all active:scale-90'>
          Weather App
        </Link>

        <Link to={'/mirodil'} className='flex-1 p-20 rounded-lg glass flex items-center justify-center min-w-[40%] text-3xl shadow-lg group hover:text-red-500 hover:shadow-red-500 transition-all active:scale-90'>
          Translate App
        </Link>

        <Link to={'/mirodil'} className='flex-1 p-20 rounded-lg glass flex items-center justify-center min-w-[40%] text-3xl shadow-lg group hover:text-red-500 hover:shadow-red-500 transition-all active:scale-90'>
          Calculator
        </Link>

        <Link to={'/mirodil'} className='flex-1 p-20 rounded-lg glass flex items-center justify-center min-w-[40%] text-3xl shadow-lg group hover:text-red-500 hover:shadow-red-500 transition-all active:scale-90'>
          Todo list
        </Link>

        <Link to={'/tap-coin'} className='flex-1 p-20 rounded-lg glass flex items-center justify-center min-w-[40%] text-3xl shadow-lg group hover:text-red-500 hover:shadow-red-500 transition-all active:scale-90'>
          Tap Coin
        </Link>

      </div>
    </div>
  )
}

export default App