import React, { useState } from 'react'
import DividerCustom from '../components/DividerCustom'

const TapCoin = () => {
    const [coin, setCoin] = useState(0)
    const [point, setPoint] = useState(1)

    const handleClick = () => {
        if (coin > 100) {
            setPoint(2)
        }

        setCoin(prev => prev + point)
    }

    return (
        <div className='container mx-auto max-w-[80%]'>
            <DividerCustom text={"TapCoin"} />

            <div className="tepa flex justify-end">
                <div class="bg-transparent text-mono border-2 flex px-5 rounded-box py-2 text-sm text-bold text-warning border-warning min-w-[340px] text-right shadow shadow-warning  items-center justify-end gap-4">
                    <span>{coin}</span>
                    <span>
                        <img src="./coin.png" className='size-8' alt="" />
                    </span>
                </div>
            </div>
            <div className="ortasi flex justify-center items-center mt-20">
                <button onClick={handleClick} className='active:scale-95 transition-all'>
                    <img src="./coin.png" alt="" />
                </button>
            </div>
            <div className="pasi"></div>
        </div>
    )
}

export default TapCoin